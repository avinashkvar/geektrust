import React from 'react'
import Products from '../MainContent/Products'

const Home = () => {
  return (
    <div>
        <Products/>
    </div>
  )
}

export default Home